# ONEHANDPHOTO AUTO WATERMARK PRO — Android project V5

โปรเจกต์ Android Studio สำหรับนำเว็บแอป V5 ไปบรรจุเป็นแอป Android

## ฟังก์ชันที่เชื่อมไว้
- เปิดแอป V5 ใน Android WebView
- เลือกรูปภาพหลายไฟล์ผ่าน Android file picker
- ส่งออก ZIP และบันทึกลง `Downloads/ONEHANDPHOTO`
- ใช้โลโก้และกรอบที่ฝังอยู่ในไฟล์ V5

## วิธี Build APK
1. แตกไฟล์ ZIP นี้บนคอมพิวเตอร์
2. เปิด Android Studio แล้วเลือก **Open** จากโฟลเดอร์ `OnehandphotoAutoWatermark`
3. รอ Gradle Sync และติดตั้ง Android SDK Platform 35 หาก Android Studio แจ้ง
4. เลือกเมนู **Build > Build Bundle(s) / APK(s) > Build APK(s)**
5. ไฟล์ debug APK จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

## หมายเหตุ
- โปรเจกต์นี้เป็น source project ยังไม่ใช่ APK ที่คอมไพล์แล้ว
- ต้องใช้ Android Studio/Android SDK และอินเทอร์เน็ตในขั้นตอน Gradle Sync
- ตัวไลบรารี JSZip ในหน้าเว็บโหลดจาก CDN จึงต้องเชื่อมต่ออินเทอร์เน็ตขณะใช้งานฟังก์ชัน ZIP
- สำหรับแจกจ่ายจริง ควรสร้าง signed release APK ผ่าน Build > Generate Signed Bundle / APK


## Build APK ผ่าน GitHub Actions (ไม่ต้องติดตั้ง Android Studio ในเครื่อง)
1. สร้าง GitHub repository ใหม่ แล้วอัปโหลดไฟล์และโฟลเดอร์ทั้งหมดที่อยู่ใน ZIP นี้
2. ไปที่แท็บ **Actions** ของ repository
3. เลือก workflow **Build ONEHANDPHOTO APK** แล้วกด **Run workflow**
4. รอให้สถานะงานเป็นสีเขียว จากนั้นเปิดรายการ workflow run ล่าสุด
5. ดาวน์โหลด Artifact ชื่อ `ONEHANDPHOTO-AUTO-WATERMARK-PRO-V5-APK`
6. แตก ZIP ที่ดาวน์โหลด แล้วติดตั้ง `app-debug.apk` บน Android

หมายเหตุ: workflow นี้สร้าง debug APK สำหรับทดสอบ ไม่ใช่ signed release APK สำหรับเผยแพร่สาธารณะ
